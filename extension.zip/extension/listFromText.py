file = open('blacklist.txt', "r")
lines = file.read().split()
print(lines)
